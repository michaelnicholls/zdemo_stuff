// Copyright (c) 2009-2020 SAP SE, All Rights Reserved
sap.ui.define([
    "sap/ui/core/Component",
    "sap/m/MessageToast",
    "sap/ushell/ui/shell/ToolAreaItem",
    "sap/m/Panel",
    "sap/m/VBox",
    "sap/m/Label",
    "sap/m/Switch"
], function (Component, MessageToast, ToolAreaItem, Panel, VBox, Label, Switch) {
    "use strict";

    var sComponentName = "zzplugin";

    return Component.extend(sComponentName + ".Component", {


        metadata: {
            manifest: "json"
        },


        /**
         * Returns the shell renderer instance in a reliable way,
         * i.e. independent from the initialization time of the plug-in.
         * This means that the current renderer is returned immediately, if it
         * is already created (plug-in is loaded after renderer creation) or it
         * listens to the &quot;rendererCreated&quot; event (plug-in is loaded
         * before the renderer is created).
         *
         *  @returns {object}
         *      a jQuery promise, resolved with the renderer instance, or
         *      rejected with an error message.
         */
        _getRenderer: function () {
            var that = this,
                oDeferred = new jQuery.Deferred(),
                oRenderer;

            that._oShellContainer = jQuery.sap.getObject("sap.ushell.Container");
            if (!that._oShellContainer) {
                oDeferred.reject("Illegal state: shell container not available; this component must be executed in a unified shell runtime context.");
            } else {
                oRenderer = that._oShellContainer.getRenderer();
                if (oRenderer) {
                    oDeferred.resolve(oRenderer);
                } else {
                    // renderer not initialized yet, listen to rendererCreated event
                    that._onRendererCreated = function (oEvent) {
                        oRenderer = oEvent.getParameter("renderer");
                        if (oRenderer) {
                            oDeferred.resolve(oRenderer);
                        } else {
                            oDeferred.reject("Illegal state: shell renderer not available after recieving 'rendererLoaded' event.");
                        }
                    };
                    that._oShellContainer.attachRendererCreatedEvent(that._onRendererCreated);
                }
            }
            return oDeferred.promise();
        },

        init: function () {

            this._getRenderer().fail(function (sErrorMessage) {
                jQuery.sap.log.error(sErrorMessage, undefined, sComponentName);
            })
                .done(function (oRenderer) {

  

  

                    //Create and display an item in the header of Fiori launchpad, in the launchpad states "App" and "Home".
                    //The new header item will be displayed on the left-hand side of the Fiori launchpad shell header.
                    oRenderer.addHeaderItem({
                        id: "bgHeaderItem",
			tooltip: "SAP GUI",
                        icon: "sap-icon://menu",
                        press: function () {
                           var oCross = sap.ushell.Container.getService("CrossApplicationNavigation");
			    var hash = (oCross && oCross.hrefForExternal({
				target: {
					semanticObject: "Shell", action: "startGUI" },
				params: {
					"sap-ui2-tcode": "SMEN" }
				}));
				oCross.toExternal({target: {shellHash: hash}});
                        }
                    }, true, false, ["home", "app"]);


   

    

  
                });
        },

        exit: function () {
            if (this._oShellContainer && this._onRendererCreated) {
                this._oShellContainer.detachRendererCreatedEvent(this._onRendererCreated);
            }
        }

    });
});