// Copyright (c) 2009-2020 SAP SE, All Rights Reserved
sap.ui.define([
    "sap/ui/core/Component",
    "sap/m/MessageToast",
    "sap/ushell/ui/shell/ToolAreaItem",
    "sap/m/Panel",
    "sap/m/VBox",
    "sap/m/Label",
    "sap/m/Switch",
    "sap/m/Input",
    "sap/m/Button",
"sap/m/Select"
], function(Component, MessageToast, ToolAreaItem, Panel, VBox, Label, Switch, Input, Button,Select) {
    "use strict";

    var sComponentName = "zzplugin";

    return Component.extend(sComponentName + ".Component", {


        metadata: {
            manifest: "json"
        },


        /**
         * Returns the shell renderer instance in a reliable way,
         * i.e. independent from the initialization time of the plug-in.
         * This means that the current renderer is returned immediately, if it
         * is already created (plug-in is loaded after renderer creation) or it
         * listens to the &quot;rendererCreated&quot; event (plug-in is loaded
         * before the renderer is created).
         *
         *  @returns {object}
         *      a jQuery promise, resolved with the renderer instance, or
         *      rejected with an error message.
         */
        _getRenderer: function() {
            var that = this,
                oDeferred = new jQuery.Deferred(),
                oRenderer;

            that._oShellContainer = jQuery.sap.getObject("sap.ushell.Container");
            if (!that._oShellContainer) {
                oDeferred.reject("Illegal state: shell container not available; this component must be executed in a unified shell runtime context.");
            } else {
                oRenderer = that._oShellContainer.getRenderer();
                if (oRenderer) {
                    oDeferred.resolve(oRenderer);
                } else {
                    // renderer not initialized yet, listen to rendererCreated event
                    that._onRendererCreated = function(oEvent) {
                        oRenderer = oEvent.getParameter("renderer");
                        if (oRenderer) {
                            oDeferred.resolve(oRenderer);
                        } else {
                            oDeferred.reject("Illegal state: shell renderer not available after recieving 'rendererLoaded' event.");
                        }
                    };
                    that._oShellContainer.attachRendererCreatedEvent(that._onRendererCreated);
                }
            }
            return oDeferred.promise();
        },

        init: function() {

            this._getRenderer().fail(function(sErrorMessage) {
                    jQuery.sap.log.error(sErrorMessage, undefined, sComponentName);
                })
                .done(function(oRenderer) {




                    //Create and display an item in the header of Fiori launchpad, in the launchpad states "App" and "Home".
                    //The new header item will be displayed on the left-hand side of the Fiori launchpad shell header.
                    oRenderer.addHeaderItem({
                        id: "bgHeaderItem",
                        tooltip: "SAP GUI",
                        icon: "sap-icon://menu",
                        press: function() {
                            var oCross = sap.ushell.Container.getService("CrossApplicationNavigation");
                            var hash = (oCross && oCross.hrefForExternal({
                                target: {
                                    semanticObject: "Shell",
                                    action: "startGUI"
                                },
                                params: {
                                    "sap-ui2-tcode": "SMEN"
                                }
                            }));
                            oCross.toExternal({
                                target: {
                                    shellHash: hash
                                }
                            });
                        }
                    }, true, false, ["home", "app"]);
                    var oUserPreferencesEntry = {
                        title: "Extra settings",
                        icon: "sap-icon://flight",
                        value: function() {
                            return jQuery.Deferred().resolve("Extra settings");
                        },
                        content: function() {
                            return jQuery.Deferred().resolve(new Panel({
                                content: [
                                    new VBox({
                                        items: [
                                            new Label({
                                                text: "Default airline"
                                            }),
              				    new Select({ id: "airline"}),
                                            new Button({
                                                id: "getcurrent",
                                                text: "Get values",
                                                press: function(oEvent) {
                                                    var service = "ZMNTAB";
						    var valuehelp = "ZMN_CARRVH";
                                                    jQuery.ajax({
                                                      
							url: '/sap/opu/odata/sap/'+service+'/'+valuehelp+'?$format=json',
                                                        type: 'GET',
                                                        success: function(json) {
							   for (var i=0;i<json.d.results.length;i++) {
			sap.ui.getCore().byId("airline").addItem(new sap.ui.core.Item({key: json.d.results[i].Carrid, text: json.d.results[i].Carrname}));
					if (json.d.results[i].default_carrier) {sap.ui.getCore().byId("airline").setSelectedKey(json.d.results[i].Carrid);}
                                                            //document.getElementById("Name-inner").value = json.d.results[0].Name;
							 };
                                                        }
                                                    });
                                                    //document.getElementById("Name-inner").value="hello";
                                                }
                                            })
                                        ]
                                    })
                                ]
                            }));
                        },
                        onSave: function() {
                            var service = "ZMNTAB";
                            var entity = "ZMN_C_TAB";
                            var token = "";
                            jQuery.ajax({
                                url: '/sap/opu/odata/sap/' + service + '/' + entity,
                                type: 'GET',
                                headers: {
                                    'X-Csrf-Token': 'Fetch'
                                },
                                xhrFields: {
                                    withCredentials: true
                                },
                                success: function(data, textStatus, xhr) {
                                    token = xhr.getResponseHeader("x-csrf-token");
                                    console.log("token:" + token);
                                    jQuery.ajax({
                                        url: "/sap/opu/odata/sap/" + service + "/set?Carrid='"+sap.ui.getCore().byId("airline").getSelectedKey()+"'",
                                        type: "POST",
                                        contentType: "application/json",
                                        headers: {
                                            "X-Csrf-Token": token
                                        },
                                        xhrFields: {
                                            withCredentials: true
                                        },
                                        success: function() {
                                            console.log("OK");
                                        }
                                    });
                                }
                            });


                            return jQuery.Deferred().resolve();
                        }
                    };

                    oRenderer.addUserPreferencesEntry(oUserPreferencesEntry);




                });
        },

        exit: function() {
            if (this._oShellContainer && this._onRendererCreated) {
                this._oShellContainer.detachRendererCreatedEvent(this._onRendererCreated);
            }
        }

    });
});